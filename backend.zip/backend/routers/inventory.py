from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from database import get_db
from models import Product, InventoryLog, ReorderOrder, Setting
from schemas import InventoryAdjust
from auth import get_current_user
from ml.reorder_engine import reorder_recommendations
from ml.forecaster import forecast_product

router = APIRouter(prefix="/api/inventory", tags=["inventory"])


@router.get("/summary")
def inventory_summary(db: Session = Depends(get_db), _=Depends(get_current_user)):
    recs = reorder_recommendations(db)
    total_units = db.query(func.coalesce(func.sum(Product.stock), 0)).scalar() or 0
    avg_daily_all = sum(r["avg_daily_demand"] for r in recs)
    days_of_cover = (total_units / avg_daily_all) if avg_daily_all > 0 else None

    settings = {s.key: s.value for s in db.query(Setting).all()}
    max_cap = float(settings.get("max_warehouse_capacity", 50000))
    fill = (total_units / max_cap) * 100 if max_cap else 0

    critical_high = [r for r in recs if r["urgency"] in ["Critical", "High"]]
    return {
        "total_units": int(total_units),
        "days_of_cover": round(float(days_of_cover), 2) if days_of_cover is not None else None,
        "reorder_required_skus": len(critical_high),
        "warehouse_fill_pct": round(float(fill), 2),
    }


@router.get("/stock-by-location")
def stock_by_location(db: Session = Depends(get_db), _=Depends(get_current_user)):
    rec_map = {r["product_id"]: r for r in reorder_recommendations(db)}
    products = db.query(Product).all()
    out = []
    for p in products:
        rec = rec_map.get(p.id, {})
        urgency = rec.get("urgency", "Low")
        badge = "Yes" if urgency in ["Critical", "High"] else "Soon" if urgency == "Medium" else "No"
        out.append(
            {
                "item": p.name,
                "location": p.location,
                "on_hand": p.stock,
                "reorder_status": badge,
                "tooltip": f"Stockout in {rec.get('days_of_stock_remaining')} days | Reorder {rec.get('reorder_qty_recommended', 0)} units",
            }
        )
    return out


@router.get("/alerts")
def inventory_alerts(db: Session = Depends(get_db), _=Depends(get_current_user)):
    recs = reorder_recommendations(db)
    out = []
    for r in recs:
        if r["urgency"] in ["Critical", "High"]:
            out.append(
                {
                    "product": r["name"],
                    "alert_type": "Stockout",
                    "message": f"Predicted stockout in {r['days_of_stock_remaining']} days. Reorder {r['reorder_qty_recommended']} units immediately.",
                    "urgency": r["urgency"],
                    "predicted_stockout_date": r["predicted_stockout_date"],
                    "recommended_reorder_qty": r["reorder_qty_recommended"],
                }
            )
        elif r["overstocking_risk"]:
            out.append(
                {
                    "product": r["name"],
                    "alert_type": "Overstock",
                    "message": "60-day forecast shows demand below current stock. Consider promotion.",
                    "urgency": "Low",
                    "overstock_units": max(r["current_stock"] - int(r["predicted_demand_60d"]), 0),
                }
            )
    return out[:20]


@router.post("/create-po")
def create_po(product_id: int, quantity: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    p = db.query(Product).filter(Product.id == product_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Product not found")
    if quantity <= 0:
        raise HTTPException(status_code=400, detail="Quantity must be positive")

    p.stock += quantity
    po = ReorderOrder(
        product_id=p.id,
        recommended_qty=quantity,
        current_stock=p.stock,
        predicted_demand_30d=0.0,
        confidence=None,
        status="Pending",
    )
    db.add(po)
    db.add(InventoryLog(product_id=p.id, change_qty=quantity, reason="Purchase Order"))
    db.commit()
    db.refresh(po)
    forecast_product(db, p.id, horizon=30)

    return {"po_id": po.id, "product": p.name, "quantity": quantity, "status": po.status}


@router.get("/logs")
def inventory_logs(db: Session = Depends(get_db), _=Depends(get_current_user)):
    rows = (
        db.query(InventoryLog, Product)
        .join(Product, Product.id == InventoryLog.product_id)
        .order_by(InventoryLog.timestamp.desc())
        .all()
    )
    return [
        {
            "product_name": p.name,
            "change_qty": log.change_qty,
            "reason": log.reason,
            "timestamp": log.timestamp,
        }
        for log, p in rows
    ]


@router.post("/adjust")
def adjust_inventory(payload: InventoryAdjust, db: Session = Depends(get_db), _=Depends(get_current_user)):
    p = db.query(Product).filter(Product.id == payload.product_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Product not found")

    p.stock += payload.change_qty
    db.add(InventoryLog(product_id=p.id, change_qty=payload.change_qty, reason=payload.reason))
    db.commit()
    forecast_product(db, p.id, horizon=30)
    return {"product_id": p.id, "new_stock": p.stock}
