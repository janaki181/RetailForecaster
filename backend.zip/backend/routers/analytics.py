from datetime import date, timedelta
from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from database import get_db
from models import Sale, DemandForecast, Product, SeasonalPattern, Setting
from auth import get_current_user
from ml.llm_insights import generate_performance_highlights, generate_recommended_actions
from ml.reorder_engine import reorder_recommendations
from ml.seasonal_detector import upcoming_seasonal_forecast

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/summary")
def summary(db: Session = Depends(get_db), _=Depends(get_current_user)):
    settings = {s.key: s.value for s in db.query(Setting).all()}
    est_vis = float(settings.get("estimated_visitors_per_order", 3))

    last7 = date.today() - timedelta(days=7)
    orders7 = db.query(func.count(Sale.id)).filter(func.date(Sale.sale_date) >= last7).scalar() or 0
    sessions_7d = int(orders7 * est_vis)

    channel_rows = db.query(Sale.channel, func.count(Sale.id)).group_by(Sale.channel).all()
    total_orders = sum(c for _, c in channel_rows) or 1
    max_channel = max((c for _, c in channel_rows), default=0)
    bounce_rate = max(0.0, 100 - ((max_channel / total_orders) * 100))

    avg_conf = db.query(func.avg(DemandForecast.confidence_score)).scalar()
    conf_pct = (float(avg_conf) * 100) if avg_conf is not None else None

    total_customers = db.query(func.count(func.distinct(Sale.customer_name))).scalar() or 0
    returning = (
        db.query(func.count())
        .select_from(
            db.query(Sale.customer_name)
            .group_by(Sale.customer_name)
            .having(func.count(Sale.id) > 1)
            .subquery()
        )
        .scalar()
    ) or 0
    returning_pct = ((returning / total_customers) * 100) if total_customers else 0.0

    return {
        "sessions_7d": sessions_7d,
        "bounce_rate_pct": round(float(bounce_rate), 2),
        "forecast_confidence_pct": round(float(conf_pct), 2) if conf_pct is not None else None,
        "returning_users_pct": round(float(returning_pct), 2),
    }


@router.get("/performance-highlights")
def performance_highlights(db: Session = Depends(get_db), _=Depends(get_current_user)):
    cat = (
        db.query(Product.category, func.coalesce(func.sum(Sale.revenue), 0.0))
        .join(Sale, Sale.product_id == Product.id)
        .group_by(Product.category)
        .all()
    )
    chan = db.query(Sale.channel, func.coalesce(func.sum(Sale.revenue), 0.0)).group_by(Sale.channel).all()
    conf = db.query(func.avg(DemandForecast.confidence_score)).scalar()
    patterns = db.query(func.count(SeasonalPattern.id)).scalar() or 0

    summary = f"Category={cat}; Channel={chan}; AvgConfidence={conf}; SeasonalPatternRows={patterns}"
    return {"highlights": generate_performance_highlights(summary)}


@router.get("/recommended-actions")
def recommended_actions(db: Session = Depends(get_db), _=Depends(get_current_user)):
    recs = reorder_recommendations(db)
    summary = str(recs[:15])
    return {"actions": generate_recommended_actions(summary)}


@router.get("/seasonal-forecast")
def seasonal_forecast(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return upcoming_seasonal_forecast(db)
